import serial
import csv

PORT = "COM9"
BAUD = 115200

filename = "Experiment3_Thermal_Shock.csv"

ser = serial.Serial(PORT, BAUD, timeout=1)

with open(filename, "w", newline="") as f:
    writer = csv.writer(f)

    writer.writerow([
        "timestamp_ms",
        "raw_adc",
        "lm35_cal_c",
        "ds18b20_c"
    ])

    print("Experiment 3 logging started.")
    print("Record 10-15 s at room temperature, then move both probes into hot water.")
    print("Press Ctrl+C after about 30-40 s in hot water.")

    try:
        while True:
            line = ser.readline().decode(errors="ignore").strip()

            if not line:
                continue

            print(line)

            parts = line.split(",")

            if len(parts) == 4:
                try:
                    writer.writerow([
                        int(parts[0]),
                        int(parts[1]),
                        float(parts[2]),
                        float(parts[3])
                    ])
                    f.flush()

                except ValueError:
                    pass

    except KeyboardInterrupt:
        print("Experiment 3 logging stopped.")

ser.close()
