# Report-Ready Sensor Fusion Section

## Fusion methods compared

Two node-level fusion methods were implemented using the same LM35DZ and DS18B20 measurement streams:

1. Adaptive confidence-weighted fusion.
2. Simple one-dimensional Kalman fusion.

The adaptive method was selected as the primary validated method, while the Kalman implementation was retained as a comparison method required for experimental evaluation.

## Characterization basis

The LM35 channel was empirically calibrated as:

    T_LM35 = 0.081567*ADC + 14.5187 °C

The calibration achieved R² = 0.999828 and an MAE of 0.0810 °C over the characterized range.

The LM35 steady-state sample variance was 0.294331 °C². The DS18B20 produced zero observed variance in the 9-bit steady-state characterization run because the temperature remained within one digital output code. A zero measurement covariance was therefore not used. For final 12-bit operation, an effective DS18B20 uncertainty floor of 0.02810 °C² was adopted using the datasheet accuracy scale and quantization variance.

Thermal-shock characterization measured probe-level time constants of approximately 13.96 s for the waterproof LM35DZ assembly and 8.04 s for the DS18B20 probe. Thus, the actual DS18B20 probe was faster than the installed LM35 assembly.

## Adaptive confidence-weighted method

The adaptive algorithm forms a dynamic uncertainty for each sensor:

    R_LM,eff = R_LM + (tau_LM*|dT/dt|)^2
    R_DS,eff = R_DS + (tau_DS*|dT/dt|)^2

The inverse uncertainties are treated as confidence values and normalized to form the fusion weights:

    C_i = 1/R_i,eff
    w_i = C_i / ΣC

The final estimate is:

    T_Adaptive = w_LM*T_LM + w_DS*T_DS

At steady state the nominal weights approach approximately 8.7% LM35 and 91.3% DS18B20. Positive normalized weights guarantee that the fused value remains between the two valid sensor values.

## Earlier lag-aware Kalman attempt

A three-state Kalman model was first tested to estimate the environmental temperature while explicitly modeling the two probe lags. The first implementation included a hard innovation gate that rejected legitimate hot-water steps. After removing that gate, the latent environmental state could extrapolate far outside the measured sensor values during rapid heating. Because the thermal model had only limited experimental identification, this de-lagging approach was rejected as the final estimator.

## Simple 1D Kalman comparison

A simpler one-state Kalman filter was then implemented:

    x = T

Prediction:

    P_minus = P + Q*dt

Measurement update:

    K = P_minus/(P_minus+R)
    x = x + K*(z-x)
    P = (1-K)*P_minus

LM35 measurements were incorporated at 10 Hz. The DS18B20 measurement was incorporated only when a genuinely new conversion completed, preventing the same digital value from being counted repeatedly as independent evidence.

## Experimental Q tuning

The process-noise rate Q was tuned by replaying one fixed recorded dataset through a set of candidate values. This ensured that every candidate was evaluated against exactly the same thermal trajectory.

The tuning metrics included steady-state output standard deviation, heating/cooling threshold lag, tracking MAE/RMSE at genuine DS18B20 updates, innovation behavior, Kalman gain, and covariance stability.

A practical comparison value of:

    Q = 0.03 °C²/s

was selected.

At Q = 0.03, the Kalman room-temperature standard deviation was approximately 0.0438 °C, nearly equal to the adaptive method value of approximately 0.0430 °C. The Kalman heating lag was approximately 5.17 s, whereas the adaptive method had an average heating lag of approximately 2.98 s.

## Interpretation

The selected 1D Kalman filter was numerically stable and produced strong steady-state smoothing. However, during heating the LM35 and DS18B20 innovations had opposite systematic signs. This occurs because the sensors do not observe the same instantaneous temperature during a rapid transient: the measured waterproof-probe time constants are different.

The simple Kalman measurement model assumes:

    z_i = T + v_i

where both sensors measure the same state plus noise. The actual transient system contains sensor-specific thermal lag. Consequently, tuning Q can reduce but cannot completely eliminate the simple Kalman tracking delay.

The adaptive confidence-weighted method handled the characterized hardware more directly because its dynamic uncertainty term explicitly uses the measured time constants. It therefore provided faster heating tracking in the recorded comparison while maintaining comparable steady-state smoothing.

## Final engineering decision

- Primary fusion method: Adaptive confidence-weighted fusion.
- Comparison method: Simple 1D Kalman filter.
- Kalman comparison parameter: Q = 0.03 °C²/s.
- Maintain separate raw LM35 and DS18B20 telemetry for diagnostics and later analysis.
