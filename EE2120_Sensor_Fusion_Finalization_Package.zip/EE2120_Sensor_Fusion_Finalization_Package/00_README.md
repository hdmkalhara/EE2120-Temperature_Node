# EE2120 Sensor Fusion Finalization Package

## Purpose

This archive collects the material used to finalize and compare the sensor-fusion methods for the EE2120 temperature-monitoring node using:

- ESP32
- LM35DZ analog temperature probe
- DS18B20 digital temperature probe
- Adaptive confidence-weighted fusion
- Simple 1D Kalman fusion

The package is arranged as an engineering audit trail: source requirements and characterization evidence, measured parameters, algorithm decisions, validation/tuning data, generated figures, and report-ready conclusions.

## Final fusion methods

### Method A — Adaptive confidence-weighted fusion

The final adaptive method uses measured noise/uncertainty and measured probe time constants:

- R_LM35 = 0.294331 °C²
- R_DS18B20 = 0.02810 °C²
- tau_LM35 = 13.95 s
- tau_DS18B20 = 8.04 s

The DS18B20-derived rate estimate is smoothed:

    tempRate_new = 0.5 * rawRate + 0.5 * tempRate_old

Effective uncertainties:

    R_LM_eff = R_LM35 + (tau_LM35 * |dT/dt|)^2
    R_DS_eff = R_DS18B20 + (tau_DS18B20 * |dT/dt|)^2

Confidence:

    C_LM = 1 / R_LM_eff
    C_DS = 1 / R_DS_eff

Normalized weights:

    w_LM = C_LM / (C_LM + C_DS)
    w_DS = C_DS / (C_LM + C_DS)

Fused temperature:

    T_Adaptive = w_LM*T_LM35 + w_DS*T_DS18B20

Because the weights are positive and normalized, the adaptive result lies between the two valid sensor values.

### Method B — Simple 1D Kalman fusion

State:

    x = T

Prediction:

    P_minus = P + Q * dt

Measurement update:

    K = P_minus / (P_minus + R)
    x_new = x_old + K*(z - x_old)
    P = (1-K)*P_minus

LM35 measurements are applied at 10 Hz. DS18B20 updates are applied only when a genuinely new conversion is available.

The experimentally selected comparison value is:

    Q = 0.03 °C²/s

This is a practical compromise for the recorded test conditions, not a universal constant.

## Main engineering conclusion

The simple 1D Kalman filter is numerically stable and can provide strong smoothing, but its model assumes both sensors observe the same instantaneous temperature state plus random measurement noise. The actual waterproof probes have different physical lags:

- LM35DZ probe tau ≈ 13.96 s
- DS18B20 probe tau ≈ 8.04 s

Therefore, during rapid heating the two measurements represent different lagged versions of the environment. The adaptive confidence method handled this mismatch more directly and tracked the heating transient faster in the recorded comparison.

## Folder map

1. `01_Decisions_and_Methodology` — complete decision history and analysis procedure.
2. `02_Project_and_Characterization_Sources` — project guide, design report, characterization report, and sensor datasheets.
3. `03_Characterization_Data` — original characterization CSV datasets.
4. `04_Firmware_and_Logging` — latest integrated firmware, dedicated Kalman tuning sketch, and Python logger.
5. `05_Kalman_Tuning_Evidence` — raw comparison/tuning dataset, replay dataset, and Q-sweep metrics.
6. `06_Generated_Figures` — all final Q-tuning and Adaptive-vs-Kalman plots.
7. `07_Report_Ready_Text` — concise report-ready results and conclusions.

## Important archive note

Some earlier intermediate raw files from the initial 3-state Kalman experiments and the first standalone adaptive-validation run were discussed and analyzed earlier but are not present in the active workspace at the time this ZIP was assembled. Their recorded findings are preserved in the decision history and evidence summary, and this limitation is stated explicitly in `Archive_Limitations.md`.
