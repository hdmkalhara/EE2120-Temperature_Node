# Archive Limitations

This package was assembled from the files available in the active project workspace plus the numerical findings preserved from the completed analysis.

The following earlier intermediate raw artifacts were discussed/analyzed previously but were not present as local files when this ZIP was assembled:

- early `fusion_validation.csv` from the innovation-gated 3-state Kalman attempt
- later `fusion_validation_Q001.csv` from the reduced-process-noise 3-state Kalman attempt
- standalone `fusion_validation_adaptive.csv` from the first final adaptive-validation run
- the earlier generated Sensor Fusion DOCX/PDF report from a previous runtime

Their important numerical findings and the decisions based on them are preserved in:
- `Sensor_Fusion_Decision_History.md`
- `Evidence_Summary.md`

The current raw characterization CSVs, current Kalman-Q tuning CSV, Q-sweep metrics, replay output, firmware, and generated tuning figures are included directly.
