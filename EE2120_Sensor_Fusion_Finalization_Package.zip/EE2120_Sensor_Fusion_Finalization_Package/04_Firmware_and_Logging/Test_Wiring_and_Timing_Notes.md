# Test Wiring and Timing Notes

## Sensor wiring used for characterized configuration

LM35DZ:
- VCC -> 5 V
- OUT -> GPIO34
- GND -> GND

DS18B20:
- VCC -> 3.3 V
- DQ -> GPIO4
- GND -> GND
- 4.7 kΩ pull-up between DQ and 3.3 V

## Important correction

An integrated-code comment previously showed LM35 VCC as 3.3 V. The LM35 datasheet specifies a minimum operating supply of about 4 V, and the characterized system used 5 V. The final sensor-fusion calibration therefore assumes the LM35 is powered from 5 V.

## Sampling

- LM35: every 100 ms (10 Hz)
- DS18B20: approximately 1 new result per second
- DS18B20 final resolution: 12 bit
- 12-bit maximum digital conversion time: 750 ms

The 750 ms digital conversion time is not the same as the measured physical thermal time constant of the waterproof probe.
