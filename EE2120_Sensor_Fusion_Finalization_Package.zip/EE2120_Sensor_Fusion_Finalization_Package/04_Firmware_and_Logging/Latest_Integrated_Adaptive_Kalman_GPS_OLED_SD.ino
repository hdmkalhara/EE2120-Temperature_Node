/*
  ================================================================
       ESP32 DISTRIBUTED TEMPERATURE MONITORING NODE
       Adaptive Weighted + 1D Kalman LM35 + DS18B20 Sensor Fusion
       + SH1106 OLED + NEO-6M GPS (quality-filtered) + MicroSD
  ================================================================

  BOARD:
    ESP32

  ------------------------------------------------
  PIN CONNECTIONS
  ------------------------------------------------

  LM35:
    VOUT  -> GPIO34
    VCC   -> 3.3V
    GND   -> GND

  DS18B20:
    DQ    -> GPIO4
    VCC   -> 3.3V
    GND   -> GND
    4.7k resistor between DQ and 3.3V

  SH1106 OLED:
    SDA   -> GPIO21
    SCL   -> GPIO22
    VCC   -> 3.3V
    GND   -> GND

  NEO-6M GPS:
    GPS TX -> GPIO16  (ESP32 UART2 RX)
    GPS RX -> GPIO17  (ESP32 UART2 TX)
    GPS GND -> GND
    GPS VCC -> appropriate supply for your NEO-6M board

  MicroSD:
    SCK  -> GPIO18
    MISO -> GPIO19
    MOSI -> GPIO23
    CS   -> GPIO5
    VCC  -> appropriate supply for your SD module
    GND  -> GND

  ------------------------------------------------
  REQUIRED LIBRARIES
  ------------------------------------------------
    OneWire
    DallasTemperature
    Adafruit GFX Library
    Adafruit SH110X
    TinyGPSPlus
    SD
    SPI
*/

#include <OneWire.h>
#include <DallasTemperature.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>
#include <TinyGPSPlus.h>
#include <SPI.h>
#include <SD.h>

// ================================================================
// PIN DEFINITIONS
// ================================================================

const int LM35_PIN    = 34;
const int DS18B20_PIN = 4;

const int GPS_RX_PIN  = 16;   // ESP32 RX <- GPS TX
const int GPS_TX_PIN  = 17;   // ESP32 TX -> GPS RX

const int SD_CS_PIN   = 5;

// GPS baud rate
const long GPS_BAUD_RATE = 9600;

// ================================================================
// OLED SETTINGS
// ================================================================

#define SCREEN_WIDTH  128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1
#define OLED_I2C_ADDR 0x3C

Adafruit_SH1106G display(
  SCREEN_WIDTH,
  SCREEN_HEIGHT,
  &Wire,
  OLED_RESET
);

// ================================================================
// LM35 CALIBRATION
// From your characterization experiment:
//   T_LM35 = 0.081567 * ADC + 14.5187
// ================================================================

const float LM35_SLOPE_M     = 0.081567f;
const float LM35_INTERCEPT_C = 14.5187f;

// ================================================================
// MEASURED SENSOR PARAMETERS (for adaptive fusion)
// ================================================================

// Steady-state measurement variance
const float R_LM35    = 0.294331f;   // deg C^2
const float R_DS18B20 = 0.02810f;    // deg C^2, non-zero 12-bit floor

// Measured waterproof-probe response constants
const float TAU_LM35    = 13.95f;    // seconds
const float TAU_DS18B20 = 8.04f;     // seconds

// ================================================================
// 1D KALMAN FILTER PARAMETERS
// ================================================================

// Process-noise variance added per second.
// This is a STARTING VALUE for the temperature-state model.
// For your final experiment/report, replace it with Q obtained from
// the variance of real temperature changes (Delta T) in your data.
const float Q_KALMAN_PER_SECOND = 0.01f;   // deg C^2 / s

// ================================================================
// FUSION TIMING
// ================================================================

const uint32_t LM35_PERIOD_MS    = 100;    // LM35 at 10 Hz
const uint32_t DS18B20_PERIOD_MS = 1000;   // DS18B20 at ~1 Hz
const uint32_t DS18B20_CONV_MS   = 750;    // 12-bit conversion time

// Set true when you want a LIVE graph in Arduino Serial Plotter.
// Set false for normal CSV text in Serial Monitor.
// MicroSD logging works in both modes.
const bool SERIAL_PLOTTER_MODE = true;

// ================================================================
// OLED / GPS TIMING
// ================================================================

// OLED screen changes every 3 seconds
const unsigned long SCREEN_SWITCH_MS = 3000;

unsigned long lastScreenSwitchTime = 0;

bool showingTemperatureScreen = true;

// ================================================================
// DS18B20
// ================================================================

OneWire oneWireBus(DS18B20_PIN);
DallasTemperature ds18b20(&oneWireBus);

// ================================================================
// GPS
// ================================================================

TinyGPSPlus gps;

// ESP32 UART2
HardwareSerial gpsSerial(2);

// ================================================================
// MICROSD
// ================================================================

const char* LOG_FILE_PATH = "/fusion_compare.csv";

bool sdCardReady = false;

// ================================================================
// FUSION STATE VARIABLES
// ================================================================

uint32_t lastLM35Time        = 0;
uint32_t lastDS18B20Request  = 0;
uint32_t ds18b20RequestTime  = 0;

bool ds18b20Converting = false;

int lastADC = 0;

float lm35Temp    = NAN;
float ds18b20Temp = NAN;
float adaptiveTemp   = NAN;

float previousDS18B20Temp = NAN;

// Estimated temperature rate from DS18B20
float tempRate = 0.0f;

// Current fusion weights
float weightLM35    = 0.0f;
float weightDS18B20 = 0.0f;

// Independent 1D Kalman-fusion state
float kalmanTemp = NAN;
float kalmanP    = 1.0f;

bool kalmanInitialized = false;
uint32_t lastKalmanPredictTime = 0;

// Last gain used for each sensor (useful for logging/analysis)
float kalmanGainLM35    = 0.0f;
float kalmanGainDS18B20 = 0.0f;

// Sensor validity
bool lm35Valid    = false;
bool ds18b20Valid = false;

// ================================================================
// GPS VALUES
// ================================================================

double latestLatitude  = 0.0;
double latestLongitude = 0.0;

unsigned long latestSatellites = 0;

float latestHDOP = 99.99;

bool latestGPSFix = false;

// GPS date/time
int latestYear   = 0;
int latestMonth  = 0;
int latestDay    = 0;

int latestHour   = 0;
int latestMinute = 0;
int latestSecond = 0;

// ================================================================
// GPS FIX QUALITY THRESHOLDS
// ================================================================

// A fix is only accepted as valid once it clears both of these.
// Tighten these further later if you still see noisy readings.

const unsigned long MIN_SATELLITES_FOR_FIX = 4;
const float         MAX_HDOP_FOR_FIX       = 5.0;

// ================================================================
// SETUP
// ================================================================

void setup() {

  Serial.begin(115200);

  delay(1000);

  Serial.println();
  Serial.println("==========================================");
  Serial.println(" ESP32 TEMPERATURE MEASUREMENT NODE");
  Serial.println(" Adaptive + Kalman Fusion + GPS + OLED + SD");
  Serial.println("==========================================");

  // ------------------------------------------------
  // ESP32 ADC configuration
  // ------------------------------------------------

  analogReadResolution(12);

  analogSetPinAttenuation(
    LM35_PIN,
    ADC_11db
  );

  Serial.println("ADC initialized.");

  // ------------------------------------------------
  // DS18B20 initialization
  // ------------------------------------------------

  ds18b20.begin();

  int deviceCount = ds18b20.getDeviceCount();

  Serial.print("DS18B20 devices detected: ");
  Serial.println(deviceCount);

  if (deviceCount == 0) {

    Serial.println(
      "WARNING: No DS18B20 detected. Check wiring."
    );
  }

  // Final deployment uses 12-bit resolution, non-blocking conversion
  ds18b20.setResolution(12);
  ds18b20.setWaitForConversion(false);

  // Start the first DS18B20 conversion
  ds18b20.requestTemperatures();

  ds18b20Converting = true;

  ds18b20RequestTime = millis();
  lastDS18B20Request  = millis();

  // ------------------------------------------------
  // GPS initialization
  // ------------------------------------------------

  gpsSerial.begin(
    GPS_BAUD_RATE,
    SERIAL_8N1,
    GPS_RX_PIN,
    GPS_TX_PIN
  );

  Serial.println("NEO-6M GPS initialized.");
  Serial.println("Waiting for satellite fix...");

  // ------------------------------------------------
  // OLED initialization
  // ------------------------------------------------

  Wire.begin(21, 22);

  if (!display.begin(OLED_I2C_ADDR, true)) {

    Serial.println("ERROR: OLED initialization failed!");

    while (true) {
      delay(500);
    }
  }

  display.clearDisplay();

  display.setTextColor(SH110X_WHITE);

  display.setTextSize(1);

  display.setCursor(10, 20);
  display.println("Temperature Node");

  display.setCursor(25, 35);
  display.println("Starting...");

  display.display();

  delay(1500);

  // ------------------------------------------------
  // MicroSD initialization
  // ------------------------------------------------

  sdCardReady = initSDCard();

  // ------------------------------------------------
  // CSV header for Serial Monitor
  // ------------------------------------------------

  Serial.println();
  Serial.println(
    "Time_ms,ADC,LM35_C,DS18B20_C,Adaptive_C,Kalman_C,"
    "Weight_LM35,Weight_DS18B20,Kalman_K_LM35,Kalman_K_DS18B20,Kalman_P,"
    "Rate_C_per_s,Fusion_Status,"
    "Latitude,Longitude,Satellites,HDOP,GPS_Fix,GPS_Date,GPS_Time"
  );

  Serial.println("System ready.");
}

// ================================================================
// MAIN LOOP
// ================================================================

void loop() {

  // ------------------------------------------------
  // IMPORTANT:
  // Process GPS continuously, every loop iteration.
  // ------------------------------------------------

  feedGPSParser();

  uint32_t now = millis();

  // ------------------------------------------------
  // LM35 acquisition at 10 Hz
  // ------------------------------------------------

  if (now - lastLM35Time >= LM35_PERIOD_MS) {

    lastLM35Time = now;

    lm35Temp = readLM35();

    lm35Valid = validLM35(lm35Temp);

    // Adaptive fusion is recalculated with the latest available
    // measurements.
    updateAdaptiveFusion();

    // Kalman filter only consumes NEW measurements.
    // Do not reuse the old DS18B20 value at 10 Hz.
    if (lm35Valid) {
      updateKalmanMeasurement(lm35Temp, R_LM35, now, true);
    }
  }

  // ------------------------------------------------
  // Finish DS18B20 conversion
  // ------------------------------------------------

  if (
    ds18b20Converting &&
    now - ds18b20RequestTime >= DS18B20_CONV_MS
  ) {

    float newDS18B20Temp = ds18b20.getTempCByIndex(0);

    ds18b20Converting = false;

    ds18b20Valid = validDS18B20(newDS18B20Temp);

    if (ds18b20Valid) {

      ds18b20Temp = newDS18B20Temp;

      // --------------------------------------------
      // Estimate rate of temperature change from
      // DS18B20 (samples are ~1 second apart, so
      // difference in deg C is approximately deg C/s)
      // --------------------------------------------

      if (isfinite(previousDS18B20Temp)) {

        float rawRate = ds18b20Temp - previousDS18B20Temp;

        // Small smoothing prevents one quantization
        // step from producing a large weight change.
        const float RATE_ALPHA = 0.5f;

        tempRate =
          RATE_ALPHA * rawRate +
          (1.0f - RATE_ALPHA) * tempRate;
      }

      previousDS18B20Temp = ds18b20Temp;
    }

    // Give the Kalman filter the new DS18B20 measurement once.
    if (ds18b20Valid) {
      updateKalmanMeasurement(ds18b20Temp, R_DS18B20, now, false);
    }

    updateAdaptiveFusion();

    // ----------------------------------------------
    // GPS + logging: once per DS18B20 update
    // ----------------------------------------------

    updateGPSValues();

    String logLine = buildLogLine(now);

    if (SERIAL_PLOTTER_MODE) {
      printPlotterLine();
    } else {
      Serial.println(logLine);
    }

    if (sdCardReady) {

      logToSDCard(logLine);
    }
  }

  // ------------------------------------------------
  // Start next DS18B20 conversion
  // ------------------------------------------------

  if (
    !ds18b20Converting &&
    now - lastDS18B20Request >= DS18B20_PERIOD_MS
  ) {

    ds18b20.requestTemperatures();

    ds18b20Converting = true;

    ds18b20RequestTime = now;
    lastDS18B20Request  = now;
  }

  // ------------------------------------------------
  // CHANGE OLED SCREEN
  // ------------------------------------------------

  if (now - lastScreenSwitchTime >= SCREEN_SWITCH_MS) {

    lastScreenSwitchTime = now;

    showingTemperatureScreen = !showingTemperatureScreen;
  }

  // ------------------------------------------------
  // UPDATE OLED
  // ------------------------------------------------

  if (showingTemperatureScreen) {

    updateTempScreen();

  } else {

    updateGPSScreen();
  }
}

// ================================================================
// LIVE SERIAL PLOTTER OUTPUT
// ================================================================

void printPlotterLine() {

  // Wait until all four curves have valid numeric values.
  if (
    !lm35Valid ||
    !ds18b20Valid ||
    !isfinite(adaptiveTemp) ||
    !isfinite(kalmanTemp)
  ) {
    return;
  }

  // Arduino Serial Plotter recognizes Label:Value pairs.
  // One line gives four temperature-response curves.
  Serial.print("LM35:");
  Serial.print(lm35Temp, 3);

  Serial.print("\tDS18B20:");
  Serial.print(ds18b20Temp, 3);

  Serial.print("\tAdaptive:");
  Serial.print(adaptiveTemp, 3);

  Serial.print("\tKalman:");
  Serial.print(kalmanTemp, 3);

  Serial.println();
}

// ================================================================
// GPS PARSER
// ================================================================

void feedGPSParser() {

  while (gpsSerial.available() > 0) {

    char c = gpsSerial.read();

    gps.encode(c);
  }
}

// ================================================================
// LM35
// ================================================================

float readLM35() {

  lastADC = analogRead(LM35_PIN);

  float temperature =
    LM35_SLOPE_M * ((float)lastADC) + LM35_INTERCEPT_C;

  return temperature;
}

bool validLM35(float t) {

  if (!isfinite(t)) {
    return false;
  }

  // Broad electrical sanity limits.
  // Characterization calibration was formally verified only
  // over the experimentally tested range.
  if (t < -10.0f || t > 100.0f) {
    return false;
  }

  return true;
}

// ================================================================
// DS18B20
// ================================================================

bool validDS18B20(float t) {

  if (!isfinite(t)) {
    return false;
  }

  // DallasTemperature disconnected-sensor indication
  if (t <= -126.0f) {
    return false;
  }

  // Reject impossible/out-of-project range values
  if (t < -10.0f || t > 100.0f) {
    return false;
  }

  return true;
}

// ================================================================
// ADAPTIVE WEIGHTED FUSION
// ================================================================

void updateAdaptiveFusion() {

  // ------------------------------------------------
  // CASE 1: Both sensors valid
  // ------------------------------------------------

  if (lm35Valid && ds18b20Valid) {

    /*
       Effective uncertainty:

       During steady temperature:
           R_eff ~= measurement variance

       During a transient, sensor lag introduces additional
       uncertainty approximately proportional to:
           tau * dT/dt

       Therefore:
           R_LM35_eff    = R_LM35    + (tau_LM35    * rate)^2
           R_DS18B20_eff = R_DS18B20 + (tau_DS18B20 * rate)^2

       Because the measured DS18B20 probe has lower noise and
       a lower time constant, it receives greater confidence.
    */

    float dynamicLM35    = TAU_LM35 * fabsf(tempRate);
    float dynamicDS18B20 = TAU_DS18B20 * fabsf(tempRate);

    float R_LM35_eff =
      R_LM35 + dynamicLM35 * dynamicLM35;

    float R_DS18B20_eff =
      R_DS18B20 + dynamicDS18B20 * dynamicDS18B20;

    // Inverse-variance confidence
    float confidenceLM35    = 1.0f / R_LM35_eff;
    float confidenceDS18B20 = 1.0f / R_DS18B20_eff;

    float confidenceSum = confidenceLM35 + confidenceDS18B20;

    weightLM35    = confidenceLM35 / confidenceSum;
    weightDS18B20 = confidenceDS18B20 / confidenceSum;

    // Positive normalized weighted average
    adaptiveTemp =
      weightLM35 * lm35Temp +
      weightDS18B20 * ds18b20Temp;
  }

  // ------------------------------------------------
  // CASE 2: DS18B20 failed
  // ------------------------------------------------

  else if (lm35Valid && !ds18b20Valid) {

    weightLM35    = 1.0f;
    weightDS18B20 = 0.0f;

    adaptiveTemp = lm35Temp;
  }

  // ------------------------------------------------
  // CASE 3: LM35 failed
  // ------------------------------------------------

  else if (!lm35Valid && ds18b20Valid) {

    weightLM35    = 0.0f;
    weightDS18B20 = 1.0f;

    adaptiveTemp = ds18b20Temp;
  }

  // ------------------------------------------------
  // CASE 4: Both sensors invalid
  // ------------------------------------------------

  else {

    weightLM35    = 0.0f;
    weightDS18B20 = 0.0f;

    // Keep previous fused value instead of inventing
    // a new measurement.
  }
}

// ================================================================
// 1D KALMAN SENSOR FUSION
// ================================================================

/*
   State:
       x = true temperature estimate

   Simple process model:
       x(k) = x(k-1) + process noise

   Prediction covariance:
       P = P + Q * dt

   Measurement update for each NEW sensor reading:
       K = P / (P + R)
       x = x + K * (z - x)
       P = (1 - K) * P

   R_LM35 and R_DS18B20 are the measured sensor variances already
   used by your adaptive method.

   Important:
   - LM35 supplies a new measurement every 100 ms.
   - DS18B20 supplies a new measurement about every 1 s.
   - The Kalman filter updates only when a NEW reading arrives.
     It does not repeatedly reuse a stale DS18B20 reading.
*/

void kalmanPredict(uint32_t nowMs) {

  if (!kalmanInitialized) {
    lastKalmanPredictTime = nowMs;
    return;
  }

  float dt =
    (float)(nowMs - lastKalmanPredictTime) / 1000.0f;

  if (dt < 0.0f) {
    dt = 0.0f;
  }

  // Avoid an unrealistically large single prediction step if the
  // processor was paused for a long time.
  if (dt > 5.0f) {
    dt = 5.0f;
  }

  kalmanP += Q_KALMAN_PER_SECOND * dt;

  lastKalmanPredictTime = nowMs;
}

void updateKalmanMeasurement(
  float measurement,
  float measurementVariance,
  uint32_t nowMs,
  bool fromLM35
) {

  if (!isfinite(measurement) || measurementVariance <= 0.0f) {
    return;
  }

  // First valid measurement initializes the filter.
  if (!kalmanInitialized) {

    kalmanTemp = measurement;
    kalmanP = measurementVariance;

    kalmanInitialized = true;
    lastKalmanPredictTime = nowMs;

    if (fromLM35) {
      kalmanGainLM35 = 1.0f;
    } else {
      kalmanGainDS18B20 = 1.0f;
    }

    return;
  }

  // -------------------- PREDICT --------------------
  kalmanPredict(nowMs);

  // --------------------- UPDATE --------------------
  float K =
    kalmanP / (kalmanP + measurementVariance);

  kalmanTemp =
    kalmanTemp + K * (measurement - kalmanTemp);

  kalmanP =
    (1.0f - K) * kalmanP;

  // Save gains so they can be inspected in the CSV file.
  if (fromLM35) {
    kalmanGainLM35 = K;
  } else {
    kalmanGainDS18B20 = K;
  }
}

// ================================================================
// FUSION STATUS
// ================================================================

const char* fusionStatus() {

  if (lm35Valid && ds18b20Valid) {
    return "FUSION_OK";
  }

  if (lm35Valid && !ds18b20Valid) {
    return "LM35_ONLY";
  }

  if (!lm35Valid && ds18b20Valid) {
    return "DS18B20_ONLY";
  }

  return "BOTH_FAULT";
}

// ================================================================
// UPDATE GPS VALUES
// ================================================================

void updateGPSValues() {

  // ------------------------------------------------
  // Number of satellites
  // ------------------------------------------------

  if (gps.satellites.isValid()) {

    latestSatellites = gps.satellites.value();

  } else {

    latestSatellites = 0;
  }

  // ------------------------------------------------
  // Signal quality (HDOP)
  // ------------------------------------------------

  if (gps.hdop.isValid()) {

    latestHDOP = gps.hdop.hdop();

  } else {

    latestHDOP = 99.99;
  }

  // ------------------------------------------------
  // Position
  // ------------------------------------------------
  // Only accept a fix once it's recent AND meets the
  // minimum satellite count / HDOP thresholds above.
  // This filters out the noisy low-satellite / high-HDOP
  // readings that come through before the GPS has fully
  // settled.
  // ------------------------------------------------

  bool fixIsRecent =
    gps.location.isValid() &&
    gps.location.age() < 5000;

  bool fixMeetsQuality =
    (latestSatellites >= MIN_SATELLITES_FOR_FIX) &&
    (latestHDOP <= MAX_HDOP_FOR_FIX);

  if (fixIsRecent && fixMeetsQuality) {

    latestGPSFix = true;

    latestLatitude  = gps.location.lat();
    latestLongitude = gps.location.lng();

  } else {

    latestGPSFix = false;
  }

  // ------------------------------------------------
  // Date
  // ------------------------------------------------

  if (gps.date.isValid()) {

    latestYear  = gps.date.year();
    latestMonth = gps.date.month();
    latestDay   = gps.date.day();
  }

  // ------------------------------------------------
  // Time
  // ------------------------------------------------

  if (gps.time.isValid()) {

    latestHour   = gps.time.hour();
    latestMinute = gps.time.minute();
    latestSecond = gps.time.second();
  }
}

// ================================================================
// MICROSD INITIALIZATION
// ================================================================

bool initSDCard() {

  Serial.println("Initializing MicroSD card...");

  if (!SD.begin(SD_CS_PIN)) {

    Serial.println("ERROR: MicroSD card mount failed.");
    Serial.println("Check wiring and make sure the card is FAT32.");

    return false;
  }

  // ------------------------------------------------
  // Check whether log file already exists
  // ------------------------------------------------

  bool fileAlreadyExists = SD.exists(LOG_FILE_PATH);

  // ------------------------------------------------
  // Open file
  // ------------------------------------------------

  File logFile = SD.open(LOG_FILE_PATH, FILE_APPEND);

  if (!logFile) {

    Serial.println("ERROR: Could not open fusion_compare.csv");

    return false;
  }

  // ------------------------------------------------
  // Create CSV header if file is new
  // ------------------------------------------------

  if (!fileAlreadyExists) {

    logFile.println(
      "Time_ms,"
      "ADC,"
      "LM35_C,"
      "DS18B20_C,"
      "Adaptive_C,"
      "Kalman_C,"
      "Weight_LM35,"
      "Weight_DS18B20,"
      "Kalman_K_LM35,"
      "Kalman_K_DS18B20,"
      "Kalman_P,"
      "Rate_C_per_s,"
      "Fusion_Status,"
      "Latitude,"
      "Longitude,"
      "Satellites,"
      "HDOP,"
      "GPS_Fix,"
      "GPS_Date,"
      "GPS_Time"
    );
  }

  logFile.close();

  Serial.println("MicroSD card ready.");
  Serial.print("Logging to: ");
  Serial.println(LOG_FILE_PATH);

  return true;
}

// ================================================================
// BUILD CSV LOG LINE
// ================================================================

String buildLogLine(unsigned long timestampMs) {

  String line = "";

  // ------------------------------------------------
  // Millisecond timestamp
  // ------------------------------------------------

  line += String(timestampMs);
  line += ",";

  // ------------------------------------------------
  // Raw ADC
  // ------------------------------------------------

  line += String(lastADC);
  line += ",";

  // ------------------------------------------------
  // LM35
  // ------------------------------------------------

  if (lm35Valid) {
    line += String(lm35Temp, 3);
  } else {
    line += "NaN";
  }

  line += ",";

  // ------------------------------------------------
  // DS18B20
  // ------------------------------------------------

  if (ds18b20Valid) {
    line += String(ds18b20Temp, 3);
  } else {
    line += "NaN";
  }

  line += ",";

  // ------------------------------------------------
  // Adaptive weighted fusion temperature
  // ------------------------------------------------

  if (isfinite(adaptiveTemp)) {
    line += String(adaptiveTemp, 3);
  } else {
    line += "NaN";
  }

  line += ",";

  // ------------------------------------------------
  // Kalman fusion temperature
  // ------------------------------------------------

  if (isfinite(kalmanTemp)) {
    line += String(kalmanTemp, 3);
  } else {
    line += "NaN";
  }

  line += ",";

  // ------------------------------------------------
  // Adaptive weights + Kalman gains/covariance + rate + status
  // ------------------------------------------------

  line += String(weightLM35, 4);
  line += ",";

  line += String(weightDS18B20, 4);
  line += ",";

  line += String(kalmanGainLM35, 4);
  line += ",";

  line += String(kalmanGainDS18B20, 4);
  line += ",";

  line += String(kalmanP, 6);
  line += ",";

  line += String(tempRate, 3);
  line += ",";

  line += fusionStatus();
  line += ",";

  // ------------------------------------------------
  // GPS position
  // ------------------------------------------------

  if (latestGPSFix) {

    line += String(latestLatitude, 6);
    line += ",";
    line += String(latestLongitude, 6);

  } else {

    line += "NO_FIX";
    line += ",";
    line += "NO_FIX";
  }

  line += ",";

  // ------------------------------------------------
  // Satellites
  // ------------------------------------------------

  line += String(latestSatellites);
  line += ",";

  // ------------------------------------------------
  // HDOP
  // ------------------------------------------------

  line += String(latestHDOP, 2);
  line += ",";

  // ------------------------------------------------
  // GPS FIX
  // ------------------------------------------------

  if (latestGPSFix) {
    line += "FIX";
  } else {
    line += "NO_FIX";
  }

  line += ",";

  // ------------------------------------------------
  // GPS DATE
  // ------------------------------------------------

  if (gps.date.isValid()) {

    char dateBuffer[11];

    sprintf(
      dateBuffer,
      "%04d-%02d-%02d",
      latestYear,
      latestMonth,
      latestDay
    );

    line += dateBuffer;

  } else {

    line += "INVALID";
  }

  line += ",";

  // ------------------------------------------------
  // GPS TIME
  // ------------------------------------------------

  if (gps.time.isValid()) {

    char timeBuffer[9];

    sprintf(
      timeBuffer,
      "%02d:%02d:%02d",
      latestHour,
      latestMinute,
      latestSecond
    );

    line += timeBuffer;

  } else {

    line += "INVALID";
  }

  return line;
}

// ================================================================
// WRITE DATA TO MICROSD
// ================================================================

void logToSDCard(const String& line) {

  File logFile = SD.open(LOG_FILE_PATH, FILE_APPEND);

  if (logFile) {

    logFile.println(line);

    logFile.close();

  } else {

    Serial.println("ERROR: Could not write to MicroSD.");
  }
}

// ================================================================
// OLED DEGREE SYMBOL
// ================================================================

void drawDegreeSymbol(int x, int y) {

  display.drawCircle(x, y, 2, SH110X_WHITE);
}

// ================================================================
// TEMPERATURE OLED SCREEN
// ================================================================

void updateTempScreen() {

  display.clearDisplay();

  display.setTextSize(1);
  display.setCursor(12, 1);
  display.print("FUSION COMPARISON");
  display.drawFastHLine(0, 11, SCREEN_WIDTH, SH110X_WHITE);

  display.setCursor(0, 15);
  display.print("Adaptive: ");
  if (isfinite(adaptiveTemp)) {
    display.print(adaptiveTemp, 1);
    display.print(" C");
  } else {
    display.print("ERR");
  }

  display.setCursor(0, 26);
  display.print("Kalman:   ");
  if (isfinite(kalmanTemp)) {
    display.print(kalmanTemp, 1);
    display.print(" C");
  } else {
    display.print("ERR");
  }

  display.drawFastHLine(0, 37, SCREEN_WIDTH, SH110X_WHITE);

  display.setCursor(0, 41);
  display.print("LM35: ");
  if (lm35Valid) {
    display.print(lm35Temp, 1);
    display.print(" C");
  } else {
    display.print("ERR");
  }

  display.setCursor(0, 52);
  display.print("DS18: ");
  if (ds18b20Valid) {
    display.print(ds18b20Temp, 1);
    display.print(" C");
  } else {
    display.print("ERR");
  }

  display.display();
}

// ================================================================
// GPS OLED SCREEN
// ================================================================

void updateGPSScreen() {

  display.clearDisplay();

  // ------------------------------------------------
  // Title
  // ------------------------------------------------

  display.setTextSize(1);
  display.setCursor(28, 2);
  display.print("GPS STATUS");

  display.drawFastHLine(0, 12, SCREEN_WIDTH, SH110X_WHITE);

  // ------------------------------------------------
  // GPS FIX
  // ------------------------------------------------

  display.setCursor(0, 17);
  display.print("Status: ");

  if (latestGPSFix) {
    display.print("FIX");
  } else {
    display.print("SEARCHING");
  }

  // ------------------------------------------------
  // Satellites
  // ------------------------------------------------

  display.setCursor(75, 17);
  display.print("S:");
  display.print(latestSatellites);

  // ------------------------------------------------
  // Latitude
  // ------------------------------------------------

  display.setCursor(0, 30);
  display.print("Lat:");

  if (latestGPSFix) {
    display.print(latestLatitude, 5);
  } else {
    display.print("---");
  }

  // ------------------------------------------------
  // Longitude
  // ------------------------------------------------

  display.setCursor(0, 42);
  display.print("Lng:");

  if (latestGPSFix) {
    display.print(latestLongitude, 5);
  } else {
    display.print("---");
  }

  // ------------------------------------------------
  // SD status
  // ------------------------------------------------

  display.setCursor(0, 54);
  display.print("SD:");

  if (sdCardReady) {
    display.print("OK");
  } else {
    display.print("FAIL");
  }

  display.display();
}
