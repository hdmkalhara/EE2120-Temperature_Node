/*
  EE2120 - Kalman Q Tuning Test Logger
  ESP32 + LM35DZ + DS18B20

  PURPOSE
  -------
  Logs EVERY 10 Hz LM35 sample and marks exactly when a NEW
  DS18B20 conversion arrives. This allows offline replay of the
  same raw measurements through many Kalman Q values.

  WIRING
  ------
  LM35DZ:
    VCC  -> 5V
    OUT  -> GPIO34
    GND  -> GND

  DS18B20:
    VCC  -> 3.3V
    DQ   -> GPIO4
    GND  -> GND
    4.7k resistor between DQ and 3.3V

  SERIAL
  ------
  115200 baud

  CSV COLUMNS
  -----------
  time_ms,ADC,LM35_C,DS18B20_C,DS_New,Adaptive_C,Kalman_C,
  w_LM,w_DS,K_LM,K_DS,Kalman_P,Innovation_LM,Innovation_DS,
  Rate_C_per_s
*/

#include <OneWire.h>
#include <DallasTemperature.h>

// ================================================================
// PINS
// ================================================================

constexpr int LM35_PIN = 34;
constexpr int DS18B20_PIN = 4;

// ================================================================
// CHARACTERIZATION PARAMETERS
// ================================================================

// LM35 calibration: T = m*ADC + c
constexpr float LM35_M = 0.081567f;
constexpr float LM35_C = 14.5187f;

// Measurement uncertainty
constexpr float R_LM35 = 0.294331f;   // degC^2, measured
constexpr float R_DS   = 0.02810f;    // degC^2, effective 12-bit floor

// Measured waterproof-probe time constants
constexpr float TAU_LM35 = 13.95f;    // s
constexpr float TAU_DS   = 8.04f;     // s

// Temporary Kalman process-noise rate.
// We will tune this OFFLINE from the recorded CSV.
constexpr float Q_PER_SECOND = 0.01f; // degC^2/s

constexpr float RATE_ALPHA = 0.5f;

// ================================================================
// TIMING
// ================================================================

constexpr uint32_t LM_PERIOD_MS = 100;     // 10 Hz
constexpr uint32_t DS_PERIOD_MS = 1000;    // ~1 Hz request interval
constexpr uint32_t DS_CONV_MS   = 750;     // 12-bit max conversion time

// ================================================================
// SENSOR OBJECTS
// ================================================================

OneWire oneWire(DS18B20_PIN);
DallasTemperature ds(&oneWire);

// ================================================================
// STATE
// ================================================================

uint32_t lastLMTime = 0;
uint32_t lastDSRequest = 0;
uint32_t dsRequestTime = 0;
bool dsConverting = false;

int adcRaw = 0;
float lmTemp = NAN;
float dsTemp = NAN;

bool lmValid = false;
bool dsValid = false;
bool dsNewSinceLastLog = false;

float previousDSTemp = NAN;
uint32_t previousDSTime = 0;
float tempRate = 0.0f;

// Adaptive fusion
float adaptiveTemp = NAN;
float wLM = 0.0f;
float wDS = 0.0f;

// 1D Kalman
float kalmanTemp = NAN;
float kalmanP = 1.0f;
bool kalmanInitialized = false;
uint32_t lastKalmanPredictTime = 0;

float lastKLM = 0.0f;
float lastKDS = 0.0f;
float lastInnovationLM = 0.0f;
float lastInnovationDS = 0.0f;

// ================================================================
// VALIDITY CHECKS
// ================================================================

bool validLM35(float t) {
  return isfinite(t) && t >= -10.0f && t <= 100.0f;
}

bool validDS18B20(float t) {
  if (!isfinite(t)) return false;
  if (t <= -126.0f) return false;  // disconnected indication
  if (t < -10.0f || t > 100.0f) return false;
  return true;
}

// ================================================================
// LM35
// ================================================================

float readLM35() {
  adcRaw = analogRead(LM35_PIN);
  return LM35_M * (float)adcRaw + LM35_C;
}

// ================================================================
// ADAPTIVE CONFIDENCE-WEIGHTED FUSION
// ================================================================

void updateAdaptiveFusion() {
  if (lmValid && dsValid) {
    float rateAbs = fabsf(tempRate);

    float dLM = TAU_LM35 * rateAbs;
    float dDS = TAU_DS * rateAbs;

    float RLM_eff = R_LM35 + dLM * dLM;
    float RDS_eff = R_DS   + dDS * dDS;

    float cLM = 1.0f / RLM_eff;
    float cDS = 1.0f / RDS_eff;
    float sum = cLM + cDS;

    wLM = cLM / sum;
    wDS = cDS / sum;

    adaptiveTemp = wLM * lmTemp + wDS * dsTemp;
  }
  else if (lmValid) {
    wLM = 1.0f;
    wDS = 0.0f;
    adaptiveTemp = lmTemp;
  }
  else if (dsValid) {
    wLM = 0.0f;
    wDS = 1.0f;
    adaptiveTemp = dsTemp;
  }
}

// ================================================================
// SIMPLE 1D KALMAN FILTER
// ================================================================

void kalmanPredict(uint32_t nowMs) {
  if (!kalmanInitialized) {
    lastKalmanPredictTime = nowMs;
    return;
  }

  float dt = (float)(nowMs - lastKalmanPredictTime) / 1000.0f;
  if (dt < 0.0f) dt = 0.0f;
  if (dt > 5.0f) dt = 5.0f;

  kalmanP += Q_PER_SECOND * dt;
  lastKalmanPredictTime = nowMs;
}

void kalmanUpdate(float z, float R, uint32_t nowMs, bool fromLM) {
  if (!isfinite(z) || R <= 0.0f) return;

  if (!kalmanInitialized) {
    kalmanTemp = z;
    kalmanP = R;
    kalmanInitialized = true;
    lastKalmanPredictTime = nowMs;

    if (fromLM) {
      lastKLM = 1.0f;
      lastInnovationLM = 0.0f;
    } else {
      lastKDS = 1.0f;
      lastInnovationDS = 0.0f;
    }
    return;
  }

  kalmanPredict(nowMs);

  float innovation = z - kalmanTemp;
  float K = kalmanP / (kalmanP + R);

  kalmanTemp = kalmanTemp + K * innovation;
  kalmanP = (1.0f - K) * kalmanP;

  if (fromLM) {
    lastKLM = K;
    lastInnovationLM = innovation;
  } else {
    lastKDS = K;
    lastInnovationDS = innovation;
  }
}

// ================================================================
// SERIAL CSV OUTPUT
// ================================================================

void printFloatOrNan(float x, int decimals) {
  if (isfinite(x)) Serial.print(x, decimals);
  else Serial.print("nan");
}

void printCSV(uint32_t nowMs) {
  Serial.print(nowMs);
  Serial.print(',');
  Serial.print(adcRaw);
  Serial.print(',');
  printFloatOrNan(lmTemp, 4);
  Serial.print(',');
  printFloatOrNan(dsTemp, 4);
  Serial.print(',');
  Serial.print(dsNewSinceLastLog ? 1 : 0);
  Serial.print(',');
  printFloatOrNan(adaptiveTemp, 4);
  Serial.print(',');
  printFloatOrNan(kalmanTemp, 4);
  Serial.print(',');
  Serial.print(wLM, 6);
  Serial.print(',');
  Serial.print(wDS, 6);
  Serial.print(',');
  Serial.print(lastKLM, 6);
  Serial.print(',');
  Serial.print(lastKDS, 6);
  Serial.print(',');
  Serial.print(kalmanP, 8);
  Serial.print(',');
  Serial.print(lastInnovationLM, 6);
  Serial.print(',');
  Serial.print(lastInnovationDS, 6);
  Serial.print(',');
  Serial.println(tempRate, 6);

  dsNewSinceLastLog = false;
}

// ================================================================
// SETUP
// ================================================================

void setup() {
  Serial.begin(115200);
  delay(1200);

  analogReadResolution(12);
  analogSetPinAttenuation(LM35_PIN, ADC_11db);

  ds.begin();
  ds.setResolution(12);
  ds.setWaitForConversion(false);

  // Start first DS conversion immediately.
  ds.requestTemperatures();
  dsConverting = true;
  dsRequestTime = millis();
  lastDSRequest = dsRequestTime;

  Serial.println("time_ms,ADC,LM35_C,DS18B20_C,DS_New,Adaptive_C,Kalman_C,w_LM,w_DS,K_LM,K_DS,Kalman_P,Innovation_LM,Innovation_DS,Rate_C_per_s");
}

// ================================================================
// MAIN LOOP
// ================================================================

void loop() {
  uint32_t now = millis();

  // --------------------------------------------------------------
  // 1) Complete a DS18B20 conversion when ready.
  // --------------------------------------------------------------
  if (dsConverting && (now - dsRequestTime >= DS_CONV_MS)) {
    float newDS = ds.getTempCByIndex(0);
    dsConverting = false;

    bool newValid = validDS18B20(newDS);

    if (newValid) {
      dsTemp = newDS;
      dsValid = true;
      dsNewSinceLastLog = true;

      // Actual elapsed time between NEW DS measurements.
      if (isfinite(previousDSTemp) && previousDSTime != 0) {
        float dtDS = (float)(now - previousDSTime) / 1000.0f;
        if (dtDS > 0.0f) {
          float rawRate = (dsTemp - previousDSTemp) / dtDS;
          tempRate = RATE_ALPHA * rawRate + (1.0f - RATE_ALPHA) * tempRate;
        }
      }

      previousDSTemp = dsTemp;
      previousDSTime = now;

      // IMPORTANT: only one Kalman update for this genuinely NEW DS sample.
      kalmanUpdate(dsTemp, R_DS, now, false);
    } else {
      dsValid = false;
    }

    updateAdaptiveFusion();
  }

  // --------------------------------------------------------------
  // 2) Start next DS18B20 conversion approximately once per second.
  // --------------------------------------------------------------
  if (!dsConverting && (now - lastDSRequest >= DS_PERIOD_MS)) {
    ds.requestTemperatures();
    dsConverting = true;
    dsRequestTime = now;
    lastDSRequest = now;
  }

  // --------------------------------------------------------------
  // 3) LM35 at 10 Hz, then log one complete CSV row.
  // --------------------------------------------------------------
  if (now - lastLMTime >= LM_PERIOD_MS) {
    lastLMTime = now;

    lmTemp = readLM35();
    lmValid = validLM35(lmTemp);

    if (lmValid) {
      kalmanUpdate(lmTemp, R_LM35, now, true);
    }

    updateAdaptiveFusion();
    printCSV(now);
  }
}
