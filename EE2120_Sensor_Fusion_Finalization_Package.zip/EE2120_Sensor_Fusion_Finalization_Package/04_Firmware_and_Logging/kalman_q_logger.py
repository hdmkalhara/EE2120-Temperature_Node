import serial
import csv
import time

PORT = "COM5"          # Change to your ESP32 COM port
BAUD_RATE = 115200
OUTPUT_FILE = "kalman_q_test.csv"

HEADER = [
    "time_ms","ADC","LM35_C","DS18B20_C","DS_New",
    "Adaptive_C","Kalman_C","w_LM","w_DS","K_LM","K_DS",
    "Kalman_P","Innovation_LM","Innovation_DS","Rate_C_per_s"
]

try:
    ser = serial.Serial(PORT, BAUD_RATE, timeout=1)
except Exception as e:
    print("Could not open serial port:", e)
    print("Close Arduino Serial Monitor/Plotter and check the COM port.")
    raise SystemExit

time.sleep(2)

with open(OUTPUT_FILE, "w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(HEADER)
    rows_saved = 0

    try:
        while True:
            line = ser.readline().decode("utf-8", errors="ignore").strip()
            if not line:
                continue

            print(line)

            if line.startswith("time_ms"):
                continue

            parts = line.split(",")

            if len(parts) != 15:
                continue

            try:
                int(parts[0])
                int(parts[1])
                for value in parts[2:]:
                    float(value)
            except ValueError:
                continue

            writer.writerow(parts)
            file.flush()
            rows_saved += 1

    except KeyboardInterrupt:
        print("Logging stopped. Rows saved:", rows_saved)
    finally:
        ser.close()

print("Saved:", OUTPUT_FILE)
