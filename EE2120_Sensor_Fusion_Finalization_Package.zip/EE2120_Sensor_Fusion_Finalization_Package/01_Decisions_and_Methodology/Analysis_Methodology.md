# Analysis Methodology

## A. Characterization-derived parameters

### LM35 calibration
Ordinary least-squares regression of DS18B20 reference temperature against averaged LM35 ADC count:

    T = m*ADC + c

Result:

    m = 0.081567 °C/count
    c = 14.5187 °C

### Measurement noise
Sample variance with denominator N-1:

    s² = Σ(x_i - x_bar)² / (N-1)

Result used for LM35:

    R_LM35 = 0.294331 °C²

### Thermal response
First-order 63.2% threshold:

    T_63.2 = T_initial + 0.632*(T_final - T_initial)
    tau = t_63.2 - t_start

Results:

    tau_LM35 ≈ 13.96 s
    tau_DS18B20 ≈ 8.04 s

## B. DS18B20 effective uncertainty floor

A zero observed variance from the 9-bit steady-state run was not used directly.

For final 12-bit operation:

    quantization step q = 0.0625 °C
    quantization variance ≈ q²/12

The ±0.5 °C datasheet accuracy scale over the relevant range was interpreted as a 3-sigma scale:

    sigma_accuracy ≈ 0.5/3
    variance_accuracy ≈ (0.5/3)²

Effective floor:

    R_DS18B20 ≈ variance_accuracy + quantization_variance
              ≈ 0.02810 °C²

This is an engineering uncertainty floor, not a direct claim of white-noise variance.

## C. Adaptive confidence-weighted fusion

1. Read/calibrate LM35.
2. Accept only genuinely new DS18B20 conversions.
3. Estimate temperature rate from successive DS18B20 readings.
4. Smooth the rate:

       tempRate_new = 0.5*rawRate + 0.5*tempRate_old

5. Calculate dynamic uncertainty:

       R_LM_eff = R_LM + (tau_LM*|tempRate|)^2
       R_DS_eff = R_DS + (tau_DS*|tempRate|)^2

6. Convert uncertainty to confidence:

       C_i = 1/R_i_eff

7. Normalize:

       w_i = C_i / ΣC

8. Fuse:

       T_adaptive = Σ w_i*T_i

## D. Simple 1D Kalman replay

The Kalman model used one temperature state.

Prediction:

    P_minus = P + Q*dt

LM35 update at each 100 ms sample:

    innovation_LM = z_LM - x
    K_LM = P_minus/(P_minus+R_LM)
    x = x + K_LM*innovation_LM
    P = (1-K_LM)*P_minus

DS18B20 update only when `DS_New == 1`:

    innovation_DS = z_DS - x
    K_DS = P_minus/(P_minus+R_DS)
    x = x + K_DS*innovation_DS
    P = (1-K_DS)*P_minus

## E. Q sweep

The same raw recorded dataset was replayed for every candidate Q. This isolates the effect of Q from run-to-run thermal differences.

Candidate Q values:

    0.0005 to 0.30 °C²/s

### Steady-state metric

Standard deviation of the Kalman output in a room-temperature window and a hot steady window.

Interpretation:

- too-small Q -> very smooth but excessive lag
- too-large Q -> faster but noisier
- useful Q -> acceptable compromise

### Heating lag metric

For several thresholds (40, 45, 50, 55, 60 °C):

    lag = t_Kalman_crossing - t_DS18B20_crossing

Mean lag across valid thresholds was used to compare candidates.

### Cooling lag metric

Equivalent threshold-crossing analysis on the cooling section.

### Error metrics at genuine DS updates

    MAE = mean(|T_Kalman - T_DS|)
    RMSE = sqrt(mean((T_Kalman - T_DS)^2))

These are tracking-agreement metrics, not absolute accuracy, because no independent traceable thermometer was used.

### Innovation analysis

    innovation = measurement - predicted state

A near-zero mean innovation at steady state is desirable.

During heating, opposite-sign LM35 and DS18B20 innovations were interpreted as evidence that the two probes were presenting different lagged temperatures to the single-state model.

### Gain analysis

    K = P_minus/(P_minus+R)

Expected behavior:

- lower R_DS -> larger DS gain
- higher R_LM -> smaller LM gain

### Covariance check

P must remain finite and positive. No instability was observed in the selected-Q replay.
