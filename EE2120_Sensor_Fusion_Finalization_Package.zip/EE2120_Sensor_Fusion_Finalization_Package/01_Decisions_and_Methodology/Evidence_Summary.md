# Evidence Summary

## Characterization evidence

### Calibration
- 5,582 calibration pairs were reported in the final characterization analysis.
- T_LM35 = 0.081567*ADC + 14.5187 °C.
- R² = 0.999828.
- MAE = 0.0810 °C.
- Tested calibration range ≈ 29.375 to 60.5625 °C.

### Steady-state noise
- LM35 sample variance = 0.294331 °C².
- LM35 standard deviation = 0.5425 °C.
- DS18B20 observed zero variation in the 9-bit steady run.
- Engineering decision: impose a positive DS uncertainty floor instead of zero covariance.

### Thermal response
- LM35 waterproof assembly tau ≈ 13.96 s.
- DS18B20 waterproof probe tau ≈ 8.04 s.
- DS18B20 reached its 63.2% target about 5.92 s earlier.

## Rejected 3-state Kalman evidence

Two observed failure mechanisms were documented:

1. Hard innovation gating rejected genuine thermal steps and could leave the estimate stuck near the old temperature.
2. After the gate was removed, the hidden environment state could overshoot well outside both sensors during rapid heating.

Representative recorded result from an intermediate test:

    LM35 ≈ 38.1 °C
    DS18B20 ≈ 45.6 °C
    estimated environment ≈ 61.6 °C

This is why the lag-deconvolving 3-state filter was not used as the final project estimator.

## Adaptive validation evidence from previous run

Previously analyzed adaptive-validation dataset:

- samples: 280
- status: 280/280 FUSION_OK
- bounded fusion violations: 0
- LM35 max: 55.221 °C
- DS18B20 max: 55.875 °C
- fused max: 55.797 °C
- w_LM approximately 0.0872 to 0.2493
- w_DS approximately 0.7507 to 0.9128

Room steady:
- LM35 std ≈ 0.423 °C
- DS18B20 std ≈ 0.150 °C
- adaptive fused std ≈ 0.147 °C

Hot steady:
- LM35 std ≈ 0.430 °C
- DS18B20 std ≈ 0.036 °C
- adaptive fused std ≈ 0.073 °C

The original standalone raw adaptive-validation CSV is not available in the active workspace used to build this ZIP. These results are retained as analysis records.

## Simple Kalman Q-tuning evidence

The current Q-tuning raw dataset and numerical replay outputs are included in this archive.

Selected Q:

    Q = 0.03 °C²/s

Selected-Q metrics:
- room std = 0.043816 °C
- hot std = 0.112604 °C
- mean heating lag = 5.166917 s
- mean cooling lag = 0.343661 s
- MAE vs genuinely new DS readings = 0.431236 °C
- RMSE vs genuinely new DS readings = 0.960083 °C
- mean K_LM in room window = 0.069466
- mean K_DS in room window = 0.500966
- mean P in room window = 0.020446

Adaptive method on same recorded dataset:
- room std = 0.0430 °C
- hot std = 0.1281 °C
- mean heating lag = 2.983 s
- mean cooling lag = -0.4178 s

Interpretation:
- Q below 0.03 gives stronger smoothing but clearly more heating lag.
- Q above 0.03 reduces lag progressively, but noise increases.
- Q = 0.03 was selected as a practical comparison point because its room steady noise nearly matches the adaptive method while improving substantially over the original Q = 0.01 response.
