# Final Parameters and Equations

## Measured parameters

| Parameter | Value | Basis |
|---|---:|---|
| LM35 calibration slope | 0.081567 °C/count | Experiment 1 |
| LM35 calibration intercept | 14.5187 °C | Experiment 1 |
| LM35 calibration R² | 0.999828 | Experiment 1 |
| LM35 calibration MAE | 0.0810 °C | Experiment 1 |
| R_LM35 | 0.294331 °C² | Experiment 2 |
| tau_LM35 | 13.96 s | Experiment 3 |
| tau_DS18B20 | 8.04 s | Experiment 3 |

## Datasheet/engineering-derived parameter

| Parameter | Value | Basis |
|---|---:|---|
| R_DS18B20 | 0.02810 °C² | 12-bit quantization + datasheet accuracy scale |

## Tuned parameter

| Parameter | Value | Basis |
|---|---:|---|
| Kalman Q | 0.03 °C²/s | Experimental Q sweep on fixed dataset |

## Implementation parameters

- LM35 acquisition: 100 ms / 10 Hz
- DS18B20: 12-bit
- DS18B20 new conversion: approximately 1 Hz
- 12-bit maximum conversion time: 750 ms
- rate smoothing alpha: 0.5

## Adaptive equations

    R_LM_eff = R_LM + (tau_LM*|dT/dt|)^2
    R_DS_eff = R_DS + (tau_DS*|dT/dt|)^2

    C_LM = 1/R_LM_eff
    C_DS = 1/R_DS_eff

    w_LM = C_LM/(C_LM+C_DS)
    w_DS = C_DS/(C_LM+C_DS)

    T_adaptive = w_LM*T_LM + w_DS*T_DS

## Simple Kalman equations

    P_minus = P + Q*dt

For each genuinely new measurement z with measurement variance R:

    K = P_minus/(P_minus+R)
    x = x + K*(z-x)
    P = (1-K)*P_minus

Final comparison value:

    Q = 0.03 °C²/s
