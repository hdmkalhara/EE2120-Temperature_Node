# Sensor Fusion Decision History

## 1. Initial design expectation

The early literature/design stage expected the analog LM35 to be the faster transient channel and the DS18B20 to be the cleaner but slower channel because of its digital conversion delay.

This expectation was reasonable from generic sensor architecture, but it was later overridden by measurements on the actual waterproof assemblies.

## 2. Sensor characterization changed the design basis

Three experiments were performed.

### Experiment 1 — LM35 calibration

Measured empirical calibration:

    T_LM35 = 0.081567 * ADC + 14.5187 °C

Additional results:

- R² = 0.999828
- MAE = 0.0810 °C
- calibration range approximately 29.375 °C to 60.5625 °C

Decision:

Use the measured ADC-to-temperature calibration directly. Do not use the ideal 10 mV/°C conversion through an assumed perfect ESP32 ADC.

### Experiment 2 — steady-state noise

Measured LM35:

    variance = 0.294331 °C²
    standard deviation = 0.5425 °C

Measured DS18B20:

    observed variance = 0.000000 °C² in that 9-bit run

Decision:

Do not assign zero covariance to DS18B20. The flat result is strongly affected by quantization and does not mean perfect certainty.

For final 12-bit operation, use an effective positive uncertainty floor:

    R_DS18B20 = 0.02810 °C²

This was constructed from the DS18B20 datasheet accuracy scale and 12-bit quantization.

### Experiment 3 — thermal shock

Measured waterproof-assembly time constants:

    tau_LM35 = 13.96 s
    tau_DS18B20 = 8.04 s

Decision:

The installed DS18B20 assembly is faster than the installed LM35 assembly. Fusion must follow measured probe-level behavior rather than the generic assumption that analog necessarily responds faster.

## 3. First advanced attempt — 3-state lag-aware Kalman estimator

The first model used states similar to:

    x = [T_environment, T_LM_probe, T_DS_probe]^T

The state transition used the two measured time constants to model first-order sensor lag.

### Failure mode A — innovation gate rejected real thermal steps

An early implementation used a hard innovation test:

    if innovation^2 > 16*S:
        reject measurement

During hot-water transitions, real temperature changes were large enough to appear as outliers. The filter rejected valid readings and the estimate became stuck near the previous temperature.

Decision:

Remove the hard innovation gate for these large legitimate thermal transients.

### Failure mode B — hidden-state over-extrapolation

After removing the gate, the latent environmental-temperature estimate became too aggressive during a rapid step.

A representative previously observed point was approximately:

    LM35 ≈ 38.1 °C
    DS18B20 ≈ 45.6 °C
    Kalman/environment estimate ≈ 61.6 °C

Reducing transient process noise did not remove the structural tendency to de-lag too aggressively.

Decision:

Reject the 3-state de-lagging Kalman estimator as the final project method. The issue was model mismatch/identifiability and limited thermal model validation, not a statement that Kalman filtering is generally invalid.

## 4. Selected robust method — adaptive confidence-weighted fusion

The replacement method uses measured steady-state uncertainty and measured probe time constants but does not attempt to reconstruct a hidden environmental state far ahead of the probes.

Core equations:

    R_LM_eff = R_LM + (tau_LM*|dT/dt|)^2
    R_DS_eff = R_DS + (tau_DS*|dT/dt|)^2

    C_LM = 1/R_LM_eff
    C_DS = 1/R_DS_eff

    w_LM = C_LM/(C_LM+C_DS)
    w_DS = C_DS/(C_LM+C_DS)

    T_adaptive = w_LM*T_LM + w_DS*T_DS

Steady-state weights from the base uncertainties are approximately:

    w_LM ≈ 0.087
    w_DS ≈ 0.913

During large transients, the measured time constants increase the dynamic uncertainty of both probes. Since the LM35 probe has the larger tau, the DS18B20 remains the dominant channel.

## 5. Adaptive-method validation

A previous final adaptive-validation run contained 280 samples.

Recorded findings from that analysis:

- 280/280 rows reported FUSION_OK
- fused value remained between LM35 and DS18B20 for 100% of rows
- LM35 range: 26.264 to 55.221 °C
- DS18B20 range: 27.000 to 55.875 °C
- fused range: 26.922 to 55.797 °C
- w_LM range: approximately 0.0872 to 0.2493
- w_DS range: approximately 0.7507 to 0.9128

Steady-region results previously calculated:

Room steady:
- LM35 standard deviation ≈ 0.423 °C
- DS18B20 standard deviation ≈ 0.150 °C
- fused standard deviation ≈ 0.147 °C

Hot steady:
- LM35 standard deviation ≈ 0.430 °C
- DS18B20 standard deviation ≈ 0.036 °C
- fused standard deviation ≈ 0.073 °C

Decision:

Accept adaptive confidence-weighted fusion as the validated primary fusion method.

## 6. Simple 1D Kalman added for comparison

A simpler Kalman formulation was then added for an objective method comparison.

State:

    x = T

Prediction:

    P_minus = P + Q*dt

Update for each genuinely new sensor measurement:

    K = P_minus/(P_minus+R)
    x = x + K*(z-x)
    P = (1-K)*P_minus

Key implementation rule:

- LM35 measurement update at 10 Hz
- DS18B20 update only when a new conversion has completed
- Never reuse the same DS18B20 value repeatedly as independent information

Initial temporary Q:

    Q = 0.01 °C²/s

## 7. Q tuning strategy

A dedicated logger captured the full 10 Hz LM35 stream and marked genuine DS18B20 updates using `DS_New`.

The same fixed raw dataset was replayed through many Q values. This avoided changing the physical experiment between candidates.

Metrics used:

- room steady-state standard deviation
- hot steady-state standard deviation
- heating threshold lag relative to new DS18B20 readings
- cooling threshold lag
- MAE/RMSE at new DS18B20 updates
- innovation behavior
- Kalman gains
- covariance P stability

## 8. Q selection

Q values tested include:

    0.0005, 0.001, 0.002, 0.003, 0.005,
    0.0075, 0.01, 0.015, 0.02, 0.03,
    0.04, 0.05, 0.075, 0.10, 0.15, 0.20, 0.30 °C²/s

A practical compromise was selected:

    Q = 0.03 °C²/s

At Q = 0.03:

- room steady Kalman std ≈ 0.0438 °C
- hot steady Kalman std ≈ 0.1126 °C
- mean heating lag ≈ 5.17 s
- mean cooling lag ≈ 0.34 s
- MAE vs genuinely new DS18B20 measurements ≈ 0.431 °C
- RMSE ≈ 0.960 °C
- mean room K_LM ≈ 0.0695
- mean room K_DS ≈ 0.501
- mean room P ≈ 0.0204

Adaptive method on the same dataset:

- room steady std ≈ 0.0430 °C
- hot steady std ≈ 0.1281 °C
- mean heating lag ≈ 2.98 s
- mean cooling lag ≈ -0.42 s

Decision:

Use Q = 0.03 °C²/s for the simple 1D Kalman comparison because it gives nearly the same room-temperature smoothing as adaptive fusion while avoiding the excessive lag of lower Q values. It is not claimed to be universally optimal.

## 9. Final interpretation

The simple 1D Kalman filter is valid, stable, and tunable, but its measurement model is incomplete during rapid thermal changes because the two waterproof probes do not observe the same instantaneous temperature.

The adaptive confidence method explicitly incorporates the unequal measured time constants and therefore tracked the heating transient faster in the recorded comparison.

Final comparison to present:

    LM35
    DS18B20
    Adaptive confidence-weighted fusion
    Simple 1D Kalman fusion with Q = 0.03 °C²/s
