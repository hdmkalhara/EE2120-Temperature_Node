#include <OneWire.h>
#include <DallasTemperature.h>

#define LM35_PIN 34
#define ONE_WIRE_BUS 4

const int NUM_SAMPLES = 100;

OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature ds18b20(&oneWire);

void setup() {
  Serial.begin(115200);

  analogSetPinAttenuation(LM35_PIN, ADC_11db);

  ds18b20.begin();
  ds18b20.setResolution(12);

  Serial.println("timestamp_ms,raw_adc_avg,ds18b20_c");
}

void loop() {
  long adcSum = 0;

  for (int i = 0; i < NUM_SAMPLES; i++) {
    adcSum += analogRead(LM35_PIN);
    delay(2);
  }

  float adcAverage = adcSum / (float)NUM_SAMPLES;

  ds18b20.requestTemperatures();
  float dsTemp = ds18b20.getTempCByIndex(0);

  Serial.print(millis());
  Serial.print(",");
  Serial.print(adcAverage, 2);
  Serial.print(",");
  Serial.println(dsTemp, 4);

  delay(800);
}