import serial
import csv

PORT = "COM9"
BAUD = 115200

filename = "Experiment1_Temperature_Sweep.csv"

ser = serial.Serial(PORT, BAUD, timeout=1)

with open(filename, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["timestamp_ms", "raw_adc_avg", "ds18b20_c"])

    print("Logging started. Press Ctrl+C to stop.")

    try:
        while True:
            line = ser.readline().decode(errors="ignore").strip()

            if not line:
                continue

            print(line)

            parts = line.split(",")

            if len(parts) == 3:
                try:
                    writer.writerow([
                        int(parts[0]),
                        float(parts[1]),
                        float(parts[2])
                    ])
                    f.flush()
                except ValueError:
                    pass

    except KeyboardInterrupt:
        print("Logging stopped.")

ser.close()
