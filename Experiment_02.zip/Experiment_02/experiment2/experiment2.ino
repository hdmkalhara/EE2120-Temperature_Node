#include <OneWire.h>
#include <DallasTemperature.h>

#define LM35_PIN 34
#define ONE_WIRE_BUS 4

OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature ds18b20(&oneWire);

const float m = 0.08156715;
const float c = 14.51870175;

unsigned long lastSample = 0;
const unsigned long SAMPLE_INTERVAL = 200;

void setup() {
  Serial.begin(115200);

  analogSetPinAttenuation(LM35_PIN, ADC_11db);

  ds18b20.begin();
  ds18b20.setResolution(9);

  // Do not block while temperature conversion occurs
  ds18b20.setWaitForConversion(false);

  // Start first conversion
  ds18b20.requestTemperatures();

  Serial.println("timestamp_ms,raw_adc,lm35_cal_c,ds18b20_c");
}

void loop() {
  if (millis() - lastSample >= SAMPLE_INTERVAL) {
    lastSample += SAMPLE_INTERVAL;

    // Read completed DS18B20 conversion
    float dsTemp = ds18b20.getTempCByIndex(0);

    // ONE raw ADC reading - no averaging
    int rawADC = analogRead(LM35_PIN);
    float lm35Temp = m * rawADC + c;

    Serial.print(millis());
    Serial.print(",");
    Serial.print(rawADC);
    Serial.print(",");
    Serial.print(lm35Temp, 4);
    Serial.print(",");
    Serial.println(dsTemp, 4);

    // Start conversion for next sample
    ds18b20.requestTemperatures();
  }
}